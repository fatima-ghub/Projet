import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CarteInteractivePage extends StatefulWidget {
  const CarteInteractivePage({super.key});

  @override
  _CarteInteractivePageState createState() => _CarteInteractivePageState();
}

class _CarteInteractivePageState extends State<CarteInteractivePage> {
  final Set<Marker> _markers = {};
  late GoogleMapController _mapController;

  // Position initiale sur le Sénégal
  final LatLng _initialPosition = LatLng(14.4974, -14.4524);

  @override
  void initState() {
    super.initState();
    _chargerTerrains();
  }

  // Charger tous les terrains depuis Firestore
  void _chargerTerrains() {
    FirebaseFirestore.instance
        .collection('terrains')
        .snapshots()
        .listen((snapshot) {
      setState(() {
        _markers.clear();
        for (var doc in snapshot.docs) {
          var data = doc.data() as Map<String, dynamic>;
          _ajouterMarqueur(doc.id, data);
        }
      });
    });
  }

  // Ajouter un marqueur sur la carte
  void _ajouterMarqueur(String id, Map<String, dynamic> data) {
    _markers.add(
      Marker(
        markerId: MarkerId(id),
        position: LatLng(
          (data['latitude'] as num).toDouble(),
          (data['longitude'] as num).toDouble(),
        ),
        icon: BitmapDescriptor.defaultMarkerWithHue(
          _getMarkerColor(data['statut']),
        ),
        infoWindow: InfoWindow(
          title: data['nom'],
          snippet:
              "Statut: ${data['statut']}\nPropriétaire: ${data['proprietaire']}\nSuperficie: ${data['superficie']} m²\nLocalité: ${data['localite']}",
          onTap: () => _modifierOuSupprimerTerrain(id, data),
        ),
      ),
    );
  }

  // Associer couleur des marqueurs à leur statut
  double _getMarkerColor(String statut) {
    switch (statut) {
      case 'Disponible':
        return BitmapDescriptor.hueGreen;
      case 'En litige':
        return BitmapDescriptor.hueRed;
      case 'En cours de procédure':
        return BitmapDescriptor.hueOrange;
      default:
        return BitmapDescriptor.hueBlue;
    }
  }

  // Ajouter un terrain
  void _ajouterTerrain(LatLng position) {
    showDialog(
      context: context,
      builder: (context) {
        TextEditingController nomController = TextEditingController();
        TextEditingController statutController = TextEditingController();
        TextEditingController proprietaireController = TextEditingController();
        TextEditingController superficieController = TextEditingController();
        TextEditingController localiteController = TextEditingController();

        return AlertDialog(
          title: const Text("Ajouter un Terrain"),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(controller: nomController, decoration: const InputDecoration(labelText: "Nom")),
                TextField(controller: statutController, decoration: const InputDecoration(labelText: "Statut")),
                TextField(controller: proprietaireController, decoration: const InputDecoration(labelText: "Propriétaire")),
                TextField(controller: superficieController, decoration: const InputDecoration(labelText: "Superficie (m²)")),
                TextField(controller: localiteController, decoration: const InputDecoration(labelText: "Localité")),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text("Annuler"),
            ),
            TextButton(
              onPressed: () async {
                await FirebaseFirestore.instance.collection('terrains').add({
                  'nom': nomController.text,
                  'statut': statutController.text,
                  'proprietaire': proprietaireController.text,
                  'superficie': double.tryParse(superficieController.text) ?? 0,
                  'localite': localiteController.text,
                  'latitude': position.latitude,
                  'longitude': position.longitude,
                });
                Navigator.of(context).pop();
              },
              child: const Text("Ajouter"),
            ),
          ],
        );
      },
    );
  }

  // Modifier ou supprimer un terrain
  void _modifierOuSupprimerTerrain(String terrainId, Map<String, dynamic> data) {
    showDialog(
      context: context,
      builder: (context) {
        TextEditingController nomController = TextEditingController(text: data['nom']);
        TextEditingController statutController = TextEditingController(text: data['statut']);
        TextEditingController proprietaireController = TextEditingController(text: data['proprietaire']);
        TextEditingController superficieController = TextEditingController(text: data['superficie'].toString());
        TextEditingController localiteController = TextEditingController(text: data['localite']);

        return AlertDialog(
          title: const Text("Modifier/Supprimer Terrain"),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(controller: nomController, decoration: const InputDecoration(labelText: "Nom")),
                TextField(controller: statutController, decoration: const InputDecoration(labelText: "Statut")),
                TextField(controller: proprietaireController, decoration: const InputDecoration(labelText: "Propriétaire")),
                TextField(controller: superficieController, decoration: const InputDecoration(labelText: "Superficie (m²)")),
                TextField(controller: localiteController, decoration: const InputDecoration(labelText: "Localité")),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () async {
                await FirebaseFirestore.instance.collection('terrains').doc(terrainId).delete();
                Navigator.of(context).pop();
              },
              child: const Text("Supprimer"),
            ),
            TextButton(
              onPressed: () async {
                await FirebaseFirestore.instance.collection('terrains').doc(terrainId).update({
                  'nom': nomController.text,
                  'statut': statutController.text,
                  'proprietaire': proprietaireController.text,
                  'superficie': double.tryParse(superficieController.text) ?? 0,
                  'localite': localiteController.text,
                });
                Navigator.of(context).pop();
              },
              child: const Text("Modifier"),
            ),
          ],
        );
      },
    );
  }

  // Recentrer la carte en fonction du nom et de la localité du terrain
  void _recentrerCarte(String localite, String nomTerrain) async {
    var snapshot = await FirebaseFirestore.instance
        .collection('terrains')
        .where('localite', isEqualTo: localite)
        .where('nom', isEqualTo: nomTerrain)
        .get();

    if (snapshot.docs.isNotEmpty) {
      var data = snapshot.docs.first.data();
      var position = LatLng(
        (data['latitude'] as num).toDouble(),
        (data['longitude'] as num).toDouble(),
      );
      _mapController.animateCamera(CameraUpdate.newLatLngZoom(position, 12));
      
      // Ajouter le marqueur du terrain trouvé
      _ajouterMarqueur(snapshot.docs.first.id, data);
    } else {
      // Afficher un message si aucun terrain n'est trouvé
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Aucun terrain trouvé avec ce nom dans cette localité.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Carte des Terrains'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              // Afficher la boîte de dialogue de recherche pour filtrer par nom et localité
              showDialog(
                context: context,
                builder: (context) {
                  TextEditingController localiteController = TextEditingController();
                  TextEditingController nomTerrainController = TextEditingController();

                  return AlertDialog(
                    title: const Text("Rechercher par nom et localité"),
                    content:
                      Column(mainAxisSize : MainAxisSize.min,
                        children:[
                          TextField(controller : localiteController , decoration : const InputDecoration(hintText : "Nom de la localité")),
                          SizedBox(height :10),
                          TextField(controller : nomTerrainController , decoration : const InputDecoration(hintText : "Nom du terrain")),
                        ]
                      ),
                    actions:[
                      ElevatedButton(onPressed : () => Navigator.of(context).pop(), child :const Text("Annuler")),
                      ElevatedButton(onPressed : () { 
                          // Appeler la méthode pour recentrer la carte avec les paramètres fournis 
                          _recentrerCarte(localiteController.text, nomTerrainController.text); 
                          Navigator.of(context).pop(); 
                        }, 
                        child :const Text("Rechercher")
                      )
                    ]
                  );
                },
              );
            },
          ),
        ],
      ),
      body:
       GoogleMap(
         initialCameraPosition:
           CameraPosition(target:_initialPosition , zoom :6),
         markers:_markers ,
         onMapCreated:(controller){
           _mapController=controller;
         },
         onTap:(LatLng position){
           // Lorsque l'utilisateur tape sur la carte, ouvrir le dialogue pour ajouter un nouveau terrain
           _ajouterTerrain(position);
         },
       )
    );
  }
}






