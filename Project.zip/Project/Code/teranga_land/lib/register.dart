import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'transparent_text.dart'; 

class Register extends StatefulWidget {
  const Register({super.key});

  @override
  _RegisterState createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final _formKey = GlobalKey<FormState>();
  var emailFieldController = TextEditingController();
  var passwordFieldController = TextEditingController();
  var confirmPasswordFieldController = TextEditingController();

  bool isProcessing = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Inscription"),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          height: MediaQuery.of(context).size.height,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blue, Colors.white],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 40.0),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  const Icon(
                    Icons.account_circle,
                    color: Colors.white,
                    size: 100,
                  ),
                  const SizedBox(height: 40),
                  TransparentText(
                    controller: emailFieldController,
                    labeltext: "Email",
                    hintText: "Entrez votre email",
                    prefixIcone: Icons.mail,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Veuillez entrer un email";
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 15),
                  TransparentText(
                    controller: passwordFieldController,
                    labeltext: "Mot de passe",
                    hintText: "Entrez votre mot de passe",
                    prefixIcone: Icons.lock,
                    obscureText: true,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Veuillez entrer un mot de passe";
                      } else if (value.length < 6) {
                        return "Le mot de passe doit contenir au moins 6 caractères";
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 15),
                  TransparentText(
                    controller: confirmPasswordFieldController,
                    labeltext: "Confirmer le mot de passe",
                    hintText: "Confirmez votre mot de passe",
                    prefixIcone: Icons.lock,
                    obscureText: true,
                    validator: (value) {
                      if (value != passwordFieldController.text) {
                        return "Les mots de passe ne correspondent pas";
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 30),
                  isProcessing
                      ? const CircularProgressIndicator()
                      : ElevatedButton(
                          onPressed: _register,
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 100, vertical: 15),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(25)),
                            backgroundColor: Colors.blue,
                          ),
                          child: const Text(
                            "S'inscrire",
                            style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                        ),
                  const SizedBox(height: 20),
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text(
                      "Retour à la connexion",
                      style: TextStyle(color: Colors.blue, fontSize: 18),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _register() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        isProcessing = true;
      });

      try {
        // Création de l'utilisateur dans Firebase Auth
        final UserCredential usercred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: emailFieldController.text,
          password: passwordFieldController.text,
        );

        // Ajout des informations utilisateur dans Firestore
        await FirebaseFirestore.instance.collection('users').doc(usercred.user!.uid).set({
          'email': emailFieldController.text,
          'role': 'user', // rôle par défaut
        });

        Fluttertoast.showToast(
          msg: "Utilisateur créé avec succès",
          backgroundColor: Colors.green,
          textColor: Colors.white,
        );

        // Rediriger l'utilisateur après l'inscription
        Navigator.pop(context);
      } catch (e) {
        Fluttertoast.showToast(
          msg: "Erreur : ${e.toString()}",
          backgroundColor: Colors.red,
          textColor: Colors.white,
        );
      } finally {
        setState(() {
          isProcessing = false;
        });
      }
    }
  }
}













