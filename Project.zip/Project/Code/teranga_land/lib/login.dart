import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart'; 
import 'package:cloud_firestore/cloud_firestore.dart'; 
import 'package:fluttertoast/fluttertoast.dart';
import 'package:teranga_land/carte_interactive_page.dart'; 
import 'package:teranga_land/carte_interactive_utilisateur.dart';
import 'package:teranga_land/profil.dart';
import 'package:teranga_land/register.dart'; 

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  bool cacherMotDePasse = true;
  final _formKey = GlobalKey<FormState>();
  var motDePasseFieldController = TextEditingController();
  var emailFieldController = TextEditingController();

  buildBackgroundImage() => Container(
        height: double.infinity,
        width: double.infinity,
        decoration: const BoxDecoration(
          image: DecorationImage(
            colorFilter: ColorFilter.mode(Colors.black45, BlendMode.darken),
            fit: BoxFit.cover,
            image: NetworkImage(
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvojwe-Miz79NP3XhJQgkwcll-ptYj0k-RUSAawdUtlA&s"),
          ),
          borderRadius: BorderRadius.zero,
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Connexion"),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          buildBackgroundImage(),
          SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 2, vertical: 80),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.location_on,
                        color: Colors.white,
                        size: 60,
                      ),
                      SizedBox(width: 10),
                      Text(
                        "Bienvenue dans TerangaLand",
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.w300,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
                Form(
                  key: _formKey, 
                  child: Column(
                    children: [
                      
                      TextFormField(
                        controller: emailFieldController,
                        decoration: const InputDecoration(
                          labelText: "Email",
                          hintText: "Entrer un email valide",
                          prefixIcon: Icon(Icons.mail),
                          filled: true,
                          fillColor: Colors.white,
                        ),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return "Merci de fournir une adresse Email";
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 15),
                     
                      TextFormField(
                        controller: motDePasseFieldController,
                        decoration: InputDecoration(
                          labelText: "Mot de passe",
                          hintText: "Entrer le mot de passe",
                          prefixIcon: const Icon(Icons.lock_clock_rounded),
                          filled: true,
                          fillColor: Colors.white,
                          suffixIcon: IconButton(
                            onPressed: () {
                              setState(() {
                                cacherMotDePasse = !cacherMotDePasse;
                              });
                            },
                            icon: Icon(
                              cacherMotDePasse
                                  ? Icons.visibility_off_outlined
                                  : Icons.visibility,
                            ),
                          ),
                        ),
                        obscureText: cacherMotDePasse,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return "Le mot de passe ne peut pas être vide";
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 15),
                      Container(
                        width: double.infinity,
                        alignment: Alignment.bottomRight,
                        child: TextButton(
                          onPressed: () {},
                          child: const Text(
                            "Mot de passe oublié ?",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                        ),
                      ),
                      
                      Container(
                        width: double.infinity,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          color: Colors.blue,
                        ),
                        child: TextButton(
                          onPressed: () async {
                            if (_formKey.currentState!.validate()) {
                              try {
                                
                                final UserCredential usercred =
                                    await FirebaseAuth.instance.signInWithEmailAndPassword(
                                  email:
                                      emailFieldController.text.trim(),
                                  password:
                                      motDePasseFieldController.text.trim(),
                                );

                               
                                if (usercred.user != null) {
                                  // Récupérer le rôle de l'utilisateur depuis Firestore
                                  String role = await _getUserRole(usercred.user!.uid);

                                  // Redirection en fonction du rôle de l'utilisateur
                                  Widget nextPage;
                                  switch (role) {
                                    case 'administrateur':
                                      nextPage = const CarteInteractivePage();
                                      break;
                                    case 'utilisateur':
                                      nextPage = const CarteInteractiveUtilisateur();
                                      break;
                                    default:
                                      nextPage = const Profil();
                                      break;
                                  }

                                  Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(builder: (context) => nextPage),
                                  );

                                  Fluttertoast.showToast(
                                    msg:
                                        "Connexion réussie",
                                    toastLength:
                                        Toast.LENGTH_SHORT,
                                    gravity:
                                        ToastGravity.CENTER,
                                    timeInSecForIosWeb:
                                        1,
                                    backgroundColor:
                                        Colors.green,
                                    textColor:
                                        Colors.white,
                                    fontSize:
                                        16.0,
                                  );
                                }
                              } catch (e) {
                                Fluttertoast.showToast(
                                  msg:
                                      "Erreur de connexion : ${e.toString()}",
                                  toastLength:
                                      Toast.LENGTH_SHORT,
                                  gravity:
                                      ToastGravity.CENTER,
                                  timeInSecForIosWeb:
                                      1,
                                  backgroundColor:
                                      Colors.red,
                                  textColor:
                                      Colors.white,
                                  fontSize:
                                      16.0,
                                );
                              }
                            }
                          },
                          child: const Text(
                            "Se connecter",
                            style:
                                TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800),
                          ),
                        ),
                      ),
                      // Redirection vers la page de création de compte
                      Container(
                        width:
                            double.infinity, 
                        alignment:
                            Alignment.center, 
                        decoration:
                            BoxDecoration(borderRadius:
                                BorderRadius.circular(15),),
                        child:
                            TextButton(onPressed:
                                () {
                              Navigator.push(context, MaterialPageRoute(builder:(context) => const Register(),),);
                            },
                              child:
                              const Text("Créer un compte", style:
                              TextStyle(color:
                              Colors.blue, fontSize:
                              20, fontWeight:
                              FontWeight.w600,),),),),],),),],),),],),);}

    // Fonction pour récupérer le rôle de l'utilisateur à partir de Firestore
    Future<String> _getUserRole(String uid) async {
      try {
        DocumentSnapshot userDoc = await FirebaseFirestore.instance
            .collection('users') // La collection 'users' stocke les rôles
            .doc(uid) // l'UID de l'utilisateur pour accéder à son document
            .get();

        if (userDoc.exists) {
          return userDoc['role'] ?? 'user'; // 'user' est un rôle par défaut
        } else {
          return 'user'; // Retourne 'user' par défaut si l'utilisateur n'a pas de rôle défini
        }
      } catch (e) {
        print('Erreur lors de la récupération du rôle : $e');
        return ''; 
      }
    }
}






