package com.example.teranga_land

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
