import 'package:flutter/material.dart';

class TransparentText extends StatefulWidget {
  final IconData prefixIcone;
  final String labeltext;
  final String hintText;
  final bool isPassword;
  final TextInputType keyboardType;
  final Widget? suffixIcon;
  final bool obscureText;
  final TextEditingController controller; 
  final String? Function(String?)? validator; 
  final bool enabled;

  const TransparentText({
    super.key,
    this.prefixIcone = Icons.fiber_manual_record_rounded,
    this.labeltext = "Pas de label",
    this.hintText = "Pas de hint",
    this.isPassword = false,
    this.keyboardType = TextInputType.text,
    this.suffixIcon,
    this.obscureText = false,
    required this.controller,
    this.validator, 
    this.enabled=true,
  });

  @override
  State<TransparentText> createState() => _TransparentTextState();
}

class _TransparentTextState extends State<TransparentText> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.5),
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextFormField(
        controller: widget.controller, 
        obscureText: widget.obscureText,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 18,
          fontWeight: FontWeight.w400,
        ),
        keyboardType: widget.keyboardType,
        validator: widget.validator,
        decoration: InputDecoration(
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 10),
          prefixIcon: Icon(
            widget.prefixIcone,
            color: Colors.white,
            size: 30,
          ),
          label: Text(
            widget.labeltext,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.w300,
            ),
          ),
          hintText: widget.hintText,
          hintStyle: const TextStyle(
            color: Colors.white60,
            fontSize: 17,
            fontWeight: FontWeight.w500,
          ),
          suffixIcon: widget.suffixIcon, 
          enabled: widget.enabled,
        ),
      ),
    );
  }
}
