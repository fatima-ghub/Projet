import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:teranga_land/transparent_text.dart'; 
import 'carte_interactive_utilisateur.dart'; 
import 'carte_interactive_page.dart'; 

class Profil extends StatefulWidget {
  const Profil({super.key});

  @override
  State<Profil> createState() => _ProfilState();
}

class _ProfilState extends State<Profil> {
  bool isProcessing = false;
  final _formKey = GlobalKey<FormState>();
  var emailFieldController = TextEditingController();
  var nomFieldController = TextEditingController(); 
  var localiteFieldController = TextEditingController(); 
  var roleFieldController = TextEditingController(); 

  @override
  void initState() {
    super.initState();
    _loadUserData(); 
  }

  Future<void> _loadUserData() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      DocumentSnapshot userDoc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      if (userDoc.exists) {
        setState(() {
          emailFieldController.text = userDoc['email'];
          nomFieldController.text = userDoc['nom'] ?? ''; 
          localiteFieldController.text = userDoc['localite'] ?? ''; 
          roleFieldController.text = userDoc['role'] ?? ''; 
        });
      }
    }
  }

  Future<void> _updateProfile() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        isProcessing = true; 
      });

      try {
        User? user = FirebaseAuth.instance.currentUser;

        // Mise à jour des informations utilisateur dans Firestore
        await FirebaseFirestore.instance.collection('users').doc(user!.uid).update({
          'role': roleFieldController.text.trim(),
          'nom': nomFieldController.text.trim(),
          'localite': localiteFieldController.text.trim(),
        });

        Fluttertoast.showToast(
          msg: "Profil mis à jour avec succès",
          backgroundColor: Colors.green,
          textColor: Colors.white,
        );

        // Redirection en fonction du rôle
        String role = roleFieldController.text.trim();
        if (role == 'utilisateur') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const CarteInteractiveUtilisateur()),
          );
        } else if (role == 'administrateur') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const CarteInteractivePage()),
          );
        }
      } catch (e) {
        Fluttertoast.showToast(
          msg: "Erreur lors de la mise à jour : ${e.toString()}",
          backgroundColor: Colors.red,
          textColor: Colors.white,
        );
      } finally {
        setState(() {
          isProcessing = false; 
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await FirebaseAuth.instance.signOut(); 
              Navigator.pushReplacementNamed(context, '/login'); 
            },
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: Center(
          child: Container(
            height: double.infinity,
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [Colors.blue, Colors.white],
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.account_box_rounded,
                      color: Colors.white,
                      size: 80,
                    ),
                    const SizedBox(height: 40),

                    TransparentText(
                      controller: emailFieldController,
                      labeltext: "Email",
                      hintText: "Entrez votre email",
                      enabled: false, 
                    ),
                    const SizedBox(height: 15),

                    TransparentText(
                      controller: nomFieldController,
                      labeltext: "Nom",
                      hintText: "Entrez votre nom",
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return "Veuillez entrer un nom";
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 15),

                    TransparentText(
                      controller: localiteFieldController,
                      labeltext: "Localité",
                      hintText: "Entrez votre localité",
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return "Veuillez entrer une localité";
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 15),

                    TransparentText(
                      controller: roleFieldController,
                      labeltext: "Rôle",
                      hintText: "Entrez votre rôle",
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return "Veuillez entrer un rôle";
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 30),

                    Container(
                      width: double.infinity,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: Colors.blue,
                      ),
                      child: TextButton(
                        onPressed: isProcessing ? null : _updateProfile, 
                        child: isProcessing
                            ? const CircularProgressIndicator()
                            : const Text(
                                "S'enregistrer",
                                style:
                                    TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}



