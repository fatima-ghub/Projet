import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:share_plus/share_plus.dart';

class CarteInteractiveUtilisateur extends StatefulWidget {
  const CarteInteractiveUtilisateur({super.key});

  @override
  _CarteInteractiveUtilisateurState createState() =>
      _CarteInteractiveUtilisateurState();
}

class _CarteInteractiveUtilisateurState
    extends State<CarteInteractiveUtilisateur> {
  final Set<Marker> _markers = {}; // Pour stocker les marqueurs
  late GoogleMapController _mapController;

  // Position initiale de la carte pour le Sénégal
  final LatLng _initialPosition = LatLng(14.4974, -14.4524);

  // Limites géographiques pour le Sénégal
  final LatLngBounds _senegalBounds = LatLngBounds(
    southwest: LatLng(12.3071, -17.5350), 
    northeast: LatLng(16.6910, -11.3481), 
  );

  @override
  void initState() {
    super.initState();
    _chargerTerrains(); 
  }

  void _chargerTerrains() async {
    FirebaseFirestore.instance.collection('terrains').snapshots().listen((snapshot) {
      setState(() {
        _markers.clear(); 
        for (var doc in snapshot.docs) {
          var data = doc.data() as Map<String, dynamic>;
          _markers.add(
            Marker(
              markerId: MarkerId(doc.id),
              position: LatLng(
                (data['latitude'] is int)
                    ? (data['latitude'] as int).toDouble()
                    : data['latitude'],
                (data['longitude'] is int)
                    ? (data['longitude'] as int).toDouble()
                    : data['longitude'],
              ),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                _getMarkerColor(data['statut']),
              ),
              onTap: () => _afficherDetailsTerrain(data),
              infoWindow: InfoWindow(
                title: data['nom'],
                snippet: "Statut: ${data['statut']}",
                onTap: () => _partagerTerrain(data),
              ),
            ),
          );
        }
      });
    });
  }

  double _getMarkerColor(String statut) {
    switch (statut) {
      case 'Disponible':
        return BitmapDescriptor.hueGreen;
      case 'En litige':
        return BitmapDescriptor.hueRed;
      case 'En cours de procédure':
        return BitmapDescriptor.hueOrange;
      default:
        return BitmapDescriptor.hueBlue;
    }
  }

  void _rechercherParcelle(String superficie, String localite) {
    FirebaseFirestore.instance
        .collection('terrains')
        .where('superficie', isEqualTo: superficie)
        .where('localite', isEqualTo: localite)
        .get()
        .then((snapshot) {
      if (snapshot.docs.isNotEmpty) {
        var data = snapshot.docs.first.data();
        var position = LatLng(
          (data['latitude'] is int)
              ? (data['latitude'] as int).toDouble()
              : data['latitude'],
          (data['longitude'] is int)
              ? (data['longitude'] as int).toDouble()
              : data['longitude'],
        );
        _mapController.animateCamera(
          CameraUpdate.newLatLngZoom(position, 15),
        );

        setState(() {
          _markers.clear();
          for (var doc in snapshot.docs) {
            var terrainData = doc.data() as Map<String, dynamic>;
            _markers.add(
              Marker(
                markerId: MarkerId(doc.id),
                position: LatLng(
                  (terrainData['latitude'] is int)
                      ? (terrainData['latitude'] as int).toDouble()
                      : terrainData['latitude'],
                  (terrainData['longitude'] is int)
                      ? (terrainData['longitude'] as int).toDouble()
                      : terrainData['longitude'],
                ),
                icon: BitmapDescriptor.defaultMarkerWithHue(
                  _getMarkerColor(terrainData['statut']),
                ),
                onTap: () => _afficherDetailsTerrain(terrainData),
                infoWindow: InfoWindow(
                  title: terrainData['nom'],
                  snippet: "Statut: ${terrainData['statut']}",
                  onTap: () => _partagerTerrain(terrainData),
                ),
              ),
            );
          }
        });
      }
    });
  }

  void _afficherDetailsTerrain(Map<String, dynamic> data) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Nom: ${data['nom']}", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text("Statut: ${data['statut']}", style: TextStyle(fontSize: 16)),
            SizedBox(height: 8),
            Text("Latitude: ${data['latitude']}", style: TextStyle(fontSize: 16)),
            SizedBox(height: 8),
            Text("Longitude: ${data['longitude']}", style: TextStyle(fontSize: 16)),
            SizedBox(height: 8),
            Text("Superficie: ${data['superficie']} m²", style: TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }

  void _partagerTerrain(Map<String, dynamic> data) {
    final String details =
        "Nom: ${data['nom']}\nStatut: ${data['statut']}\nLatitude: ${data['latitude']}\nLongitude: ${data['longitude']}\nSuperficie: ${data['superficie']} m²";
    Share.share(details, subject: "Informations sur le terrain");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Carte Interactive - Utilisateur"),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) {
                  TextEditingController superficieController =
                      TextEditingController();
                  TextEditingController localiteController =
                      TextEditingController();
                  return AlertDialog(
                    title: Text("Rechercher une parcelle"),
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextField(
                          controller: superficieController,
                          decoration: InputDecoration(hintText: "Superficie"),
                        ),
                        TextField(
                          controller: localiteController,
                          decoration: InputDecoration(hintText: "Localité spécifique"),
                        ),
                      ],
                    ),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        child: Text("Annuler"),
                      ),
                      TextButton(
                        onPressed: () {
                          _rechercherParcelle(
                              superficieController.text, localiteController.text);
                          Navigator.of(context).pop();
                        },
                        child: Text("Rechercher"),
                      ),
                    ],
                  );
                },
              );
            },
          ),
        ],
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: _initialPosition,
          zoom: 6,
        ),
        markers: _markers,
        onMapCreated: (controller) {
          _mapController = controller;
          _mapController.animateCamera(
            CameraUpdate.newLatLngBounds(
              _senegalBounds,
              50, 
            ),
          );
        },
      ),
    );
  }
}